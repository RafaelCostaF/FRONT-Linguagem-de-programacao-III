// src/app/profile/page.js
'use client';
import React, { useState } from 'react';
import PostForm from '../components/PostForm';
import Posts from '../components/Posts';
import { useAuth } from '../context/AuthContext';

const ProfilePage = () => {
  const [posts, setPosts] = useState([]);
  const { user } = useAuth();

  const handlePostSubmit = (newPost) => {
    setPosts([newPost, ...posts]);
  };

  return (
    <div>
      <h1>{user ? user.email : 'User'} Profile</h1>
      <PostForm onPostSubmit={handlePostSubmit} />
      {posts.map((post) => (
        <Posts
          key={post.id}
          avatarLetter="U" // Exemplo de avatarLetter, ajuste conforme necessário
          avatarColor="#f44336" // Exemplo de avatarColor, ajuste conforme necessário
          username={user ? user.email : 'User'} // Exemplo de username, ajuste conforme necessário
          timestamp={post.timestamp}
          content={post.content}
          mediaType={post.mediaType}
          mediaSrc={post.mediaSrc}
          detailedContent={post.detailedContent}
        />
      ))}
    </div>
  );
};

export default ProfilePage;
