// src/signup/page.js
'use client';
import React, { useState } from 'react';
import { signup } from '../util/api';
import { useAuth } from '../context/AuthContext';
import styles from '../styles/Signup.module.css';

const Signup = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [fullName, setFullName] = useState('');
    const { login } = useAuth();

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const user = await signup(email, password, fullName);
            login(email, user.token); // Supondo que a resposta contém um token JWT
        } catch (error) {
            console.error('Erro no cadastro:', error);
        }
    };

    return (
        <div className={styles.container}>
            <form onSubmit={handleSubmit} className={styles.form}>
                <input
                    type="text"
                    placeholder="Nome completo"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                    className={styles.input}
                />
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className={styles.input}
                />
                <input
                    type="password"
                    placeholder="Senha"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className={styles.input}
                />
                <button type="submit" className={styles.button}>Cadastrar</button>
                <a href="/login" className={`${styles.button} ${styles.signupButton}`}>Login</a>
            </form>
        </div>
    );
};

export default Signup;
