// src/components/AppRouter.js
'use client';
import React from 'react';
import { useRouter } from 'next/navigation'; // Importe de next/navigation em vez de next/router
import Login from '../login/page';
import Signup from '../signup/page';
import ProfilePage from '../profile/page'; // Ajuste para o caminho correto
import Home from '../page'; // Ajuste de importação para a página inicial
import { AuthProvider, useAuth } from '../context/AuthContext';

const AppRouter = () => {
    const router = useRouter();
    const { isAuthenticated } = useAuth();

    return (
        <div>
            {router.pathname === '/login' && <Login />}
            {router.pathname === '/signup' && <Signup />}
            {isAuthenticated ? (
                router.pathname === '/profile' && <ProfilePage />
            ) : (
                router.push('/login')
            )}
            {router.pathname === '/' && <Home />}
        </div>
    );
};

const AppWrapper = () => (
    <AuthProvider>
        <AppRouter />
    </AuthProvider>
);

export default AppWrapper;
