import React from 'react';
import Chat from '../components/Chat';

function ChatPage() {
    return <Chat />;
}

export default ChatPage;
