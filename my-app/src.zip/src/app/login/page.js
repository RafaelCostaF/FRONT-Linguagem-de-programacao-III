// src/app/login/page.js
'use client';
import React from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../context/AuthContext';
import styles from '../styles/Login.module.css';

export default function Login() {
    const { login } = useAuth();
    const router = useRouter();

    async function handleSubmit(event) {
        event.preventDefault();

        const formData = new FormData(event.currentTarget);
        const email = formData.get('email');
        const password = formData.get('password');

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
            });

            if (response.ok) {
                const data = await response.json();
                login(email, data.token); // Usa a função login do contexto para atualizar o estado de autenticação
            } else {
                console.error('Erro no login:', response.statusText);
                // Lógica para tratamento de erro, como exibir uma mensagem de erro para o usuário
            }
        } catch (error) {
            console.error('Erro no login:', error);
            // Lógica para tratamento de erro, como exibir uma mensagem de erro para o usuário
        }
    }

    return (
        <form onSubmit={handleSubmit} className={styles.form}>
            <input
                type="email"
                name="email"
                placeholder="Email"
                required
                className={styles.input}
            />
            <input
                type="password"
                name="password"
                placeholder="Senha"
                required
                className={styles.input}
            />
            <button type="submit" className={styles.button}>Entrar</button>
            <a href="/signup" className={`${styles.button} ${styles.signupButton}`}>Cadastrar</a>
        </form>
    );
}
